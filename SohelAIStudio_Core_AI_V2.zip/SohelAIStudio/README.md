# Sohel AI Studio V2 — Core + AI

CapCut-style editing experience for Android, built with Flutter.

## Included
- Video picker and preview
- Timeline-style editor UI
- Speed control
- Editing tool surface: trim, split, merge, music, text, filter, crop, rotate, mute
- AI actions: Auto Caption, Translate, Background Remove
- Login/home foundation

## Build
```bash
flutter pub get
flutter build apk --release
```

## AI backend
Set your backend when building:
```bash
flutter build apk --release --dart-define=AI_BASE_URL=https://YOUR-DOMAIN.example/api
```
The backend should expose:
- POST `/caption`
- POST `/translate`
- POST `/background-remove`

Do not put private API keys directly in the APK.

## Important
The editor UI and integration points are included. Real Trim/Split/Merge/Export requires FFmpeg or native Android media processing to be connected; AI features require a working backend/API.
