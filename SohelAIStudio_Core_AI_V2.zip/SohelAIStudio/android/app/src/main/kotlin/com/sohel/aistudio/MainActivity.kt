package com.sohel.aistudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
