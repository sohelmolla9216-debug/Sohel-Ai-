import 'package:image_picker/image_picker.dart';

class TranslateService {
  static final ImagePicker _picker = ImagePicker();

  static Future<XFile?> pickVideo() {
    return _picker.pickVideo(source: ImageSource.gallery);
  }

  // Add your speech-to-text and translation API integration here.
}
