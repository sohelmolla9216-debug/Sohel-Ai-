import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class AIService {
  // Set this to your own secure backend URL. Do not ship private API keys in the APK.
  static const String baseUrl = String.fromEnvironment('AI_BASE_URL', defaultValue: '');

  Future<Map<String, dynamic>> _send(String path, XFile file, {Map<String,String> fields = const {}}) async {
    if (baseUrl.isEmpty) throw Exception('AI_BASE_URL not configured');
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl$path'));
    req.fields.addAll(fields);
    req.files.add(await http.MultipartFile.fromPath('file', file.path));
    final res = await req.send();
    final body = await res.stream.bytesToString();
    if (res.statusCode < 200 || res.statusCode >= 300) throw Exception('HTTP ${res.statusCode}: $body');
    return jsonDecode(body) as Map<String, dynamic>;
  }

  Future<Map<String,dynamic>> autoCaption(XFile file) => _send('/caption', file);
  Future<Map<String,dynamic>> translate(XFile file, String language) => _send('/translate', file, fields: {'target_language': language});
  Future<Map<String,dynamic>> removeBackground(XFile file) => _send('/background-remove', file);
}
