import 'package:image_picker/image_picker.dart';

class PhotoService {
  static final ImagePicker _picker = ImagePicker();

  static Future<XFile?> pickImage() {
    return _picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
  }
}
