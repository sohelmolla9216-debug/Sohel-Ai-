import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/photo_service.dart';

class BackgroundRemovePage extends StatefulWidget {
  const BackgroundRemovePage({super.key});
  @override
  State<BackgroundRemovePage> createState() => _BackgroundRemovePageState();
}

class _BackgroundRemovePageState extends State<BackgroundRemovePage> {
  XFile? image;
  bool processing = false;

  Future<void> select() async {
    image = await PhotoService.pickImage();
    setState(() {});
  }

  Future<void> remove() async {
    if (image == null) return;
    setState(() => processing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => processing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connect a background-removal API to produce the final transparent image.')),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Background Remove')),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.content_cut, size: 85, color: Colors.deepPurpleAccent),
          const SizedBox(height: 18),
          const Text('Remove Background', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Text('Select an image, then process it with your configured AI service.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 25),
          FilledButton.icon(onPressed: select, icon: const Icon(Icons.photo), label: const Text('Select Image')),
          const SizedBox(height: 12),
          if (image != null) Text(image!.name),
          if (image != null) ...[
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: processing ? null : remove,
              icon: processing ? const SizedBox(width: 18,height:18,child:CircularProgressIndicator()) : const Icon(Icons.auto_fix_high),
              label: Text(processing ? 'Processing...' : 'Remove Background')),
          ],
        ]),
      ),
    ),
  );
}
