import 'package:flutter/material.dart';
import '../widgets/feature_card.dart';
import 'video_editor.dart';
import 'photo_editor.dart';
import 'background_remove.dart';
import 'video_translate.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.video_library_rounded, 'Video Editor', 'Cut, trim, preview', const VideoEditorPage()),
      (Icons.photo_rounded, 'Photo Editor', 'Crop, filter, adjust', const PhotoEditorPage()),
      (Icons.content_cut_rounded, 'Background Remove', 'Remove image background', const BackgroundRemovePage()),
      (Icons.translate_rounded, 'Video Translate', 'Subtitle & translate', const VideoTranslatePage()),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sohel AI Studio', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.person_outline)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Welcome 👋', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            const Text('What do you want to create today?', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 22),
            Expanded(
              child: GridView.builder(
                itemCount: items.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14,
                  childAspectRatio: .95,
                ),
                itemBuilder: (_, i) => FeatureCard(
                  icon: items[i].$1,
                  title: items[i].$2,
                  subtitle: items[i].$3,
                  onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => items[i].$4)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
