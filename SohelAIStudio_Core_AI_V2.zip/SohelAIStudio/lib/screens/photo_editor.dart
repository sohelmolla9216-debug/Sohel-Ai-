import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class PhotoEditorPage extends StatefulWidget {
  const PhotoEditorPage({super.key});
  @override
  State<PhotoEditorPage> createState() => _PhotoEditorPageState();
}

class _PhotoEditorPageState extends State<PhotoEditorPage> {
  XFile? image;

  Future<void> pick() async {
    image = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Photo Editor')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('🖼️  Photo Editor', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Crop, filter, adjust brightness and add text.', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: pick, icon: const Icon(Icons.photo_library), label: const Text('Select Photo')),
        if (image != null) ...[
          const SizedBox(height: 16),
          Text(image!.name),
          const SizedBox(height: 16),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _tool(Icons.crop, 'Crop'), _tool(Icons.tune, 'Adjust'),
            _tool(Icons.filter, 'Filter'), _tool(Icons.text_fields, 'Text'),
            _tool(Icons.save_alt, 'Save'),
          ]),
        ],
      ],
    ),
  );

  Widget _tool(IconData icon, String text) => OutlinedButton.icon(
    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$text tool is ready for the next processing step.'))),
    icon: Icon(icon), label: Text(text),
  );
}
