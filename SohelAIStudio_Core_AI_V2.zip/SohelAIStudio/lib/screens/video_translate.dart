import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/translate_service.dart';

class VideoTranslatePage extends StatefulWidget {
  const VideoTranslatePage({super.key});
  @override
  State<VideoTranslatePage> createState() => _VideoTranslatePageState();
}

class _VideoTranslatePageState extends State<VideoTranslatePage> {
  XFile? video;
  String language = 'বাংলা';
  bool processing = false;

  Future<void> pick() async {
    video = await TranslateService.pickVideo();
    setState(() {});
  }

  Future<void> translate() async {
    if (video == null) return;
    setState(() => processing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => processing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Connect speech-to-text/translation APIs to generate subtitles.')),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Video Translate')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('🌐  Video Translate', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Create translated subtitles from video speech.', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: pick, icon: const Icon(Icons.video_library), label: const Text('Select Video')),
        if (video != null) ...[
          const SizedBox(height: 14),
          Text(video!.name),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: language,
            decoration: const InputDecoration(labelText: 'Target Language', border: OutlineInputBorder()),
            items: const ['বাংলা', 'English', 'हिन्दी', 'العربية']
              .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => language = v ?? language),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: processing ? null : translate,
            icon: processing ? const SizedBox(width:18,height:18,child:CircularProgressIndicator()) : const Icon(Icons.translate),
            label: Text(processing ? 'Processing...' : 'Translate Video'),
          ),
        ],
      ],
    ),
  );
}
