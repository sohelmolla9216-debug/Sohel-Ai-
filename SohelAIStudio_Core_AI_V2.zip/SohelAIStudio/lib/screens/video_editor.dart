import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../services/video_service.dart';
import '../services/ai_service.dart';

class VideoEditorPage extends StatefulWidget {
  const VideoEditorPage({super.key});
  @override State<VideoEditorPage> createState() => _VideoEditorPageState();
}

class _VideoEditorPageState extends State<VideoEditorPage> {
  final picker = ImagePicker();
  final videoService = VideoService();
  final ai = AIService();
  XFile? file;
  VideoPlayerController? controller;
  double speed = 1.0;
  bool busy = false;
  String aiStatus = '';

  Future<void> selectVideo() async {
    final f = await picker.pickVideo(source: ImageSource.gallery);
    if (f == null) return;
    await controller?.dispose();
    final c = VideoPlayerController.file(await videoService.toFile(f));
    await c.initialize();
    setState(() { file = f; controller = c; });
    c.play();
  }

  Future<void> runAI(String action) async {
    if (file == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('আগে একটি ভিডিও নির্বাচন করুন')));
      return;
    }
    setState(() { busy = true; aiStatus = '$action চলছে...'; });
    try {
      if (action == 'Auto Caption') await ai.autoCaption(file!);
      if (action == 'Translate') await ai.translate(file!, 'bn');
      if (action == 'Background Remove') await ai.removeBackground(file!);
      setState(() => aiStatus = '$action-এর জন্য API response প্রস্তুত।');
    } catch (e) {
      setState(() => aiStatus = 'API সংযোগ দিন: $e');
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override void dispose() { controller?.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final c = controller;
    return Scaffold(
      appBar: AppBar(title: const Text('Sohel AI • Video Editor'), actions: [IconButton(onPressed: selectVideo, icon: const Icon(Icons.add))]),
      body: Column(children: [
        Expanded(flex: 5, child: Container(color: Colors.black, width: double.infinity, child: c != null && c.value.isInitialized
          ? Stack(alignment: Alignment.center, children: [AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)), IconButton(onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()), iconSize: 60, icon: Icon(c.value.isPlaying ? Icons.pause_circle : Icons.play_circle, color: Colors.white))])
          : const Center(child: Text('ভিডিও নির্বাচন করুন', style: TextStyle(color: Colors.white70))))),
        Expanded(flex: 6, child: ListView(padding: const EdgeInsets.all(12), children: [
          if (c != null) VideoProgressIndicator(c, allowScrubbing: true),
          const SizedBox(height: 10),
          _timeline(),
          const SizedBox(height: 12),
          const Text('Editing Tools', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _tool(Icons.content_cut,'Trim'), _tool(Icons.call_split,'Split'), _tool(Icons.merge_type,'Merge'),
            _tool(Icons.music_note,'Music'), _tool(Icons.text_fields,'Text'), _tool(Icons.filter,'Filter'),
            _tool(Icons.crop,'Crop'), _tool(Icons.rotate_right,'Rotate'), _tool(Icons.volume_off,'Mute'),
          ]),
          const SizedBox(height: 14),
          const Text('Speed', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Slider(min: .25, max: 4, divisions: 15, value: speed, label: '${speed.toStringAsFixed(2)}x', onChanged: (v) { setState(() => speed=v); c?.setPlaybackSpeed(v); }),
          const Text('AI Tools', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _ai(Icons.subtitles,'Auto Caption','Auto Caption'), _ai(Icons.translate,'Translate','Translate'), _ai(Icons.auto_fix_high,'BG Remove','Background Remove'),
          ]),
          if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
          if (aiStatus.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(aiStatus, style: const TextStyle(color: Colors.grey))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: file == null ? null : () => videoService.exportReady(), icon: const Icon(Icons.save_alt), label: const Text('Export Video')),
        ])),
      ]),
    );
  }

  Widget _timeline() => Container(height: 72, decoration: BoxDecoration(color: const Color(0xFF181D30), borderRadius: BorderRadius.circular(12)), child: Row(children: [
    const SizedBox(width: 12), const Icon(Icons.movie, color: Colors.deepPurpleAccent), const SizedBox(width: 8),
    Expanded(child: Container(height: 48, decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.deepPurpleAccent)), child: const Center(child: Text('Timeline • Drag / Split / Trim')))), const SizedBox(width: 12)
  ]));
  Widget _tool(IconData i,String t) => OutlinedButton.icon(onPressed: () => _msg('$t tool'), icon: Icon(i), label: Text(t));
  Widget _ai(IconData i,String t,String action) => FilledButton.tonalIcon(onPressed: busy ? null : () => runAI(action), icon: Icon(i), label: Text(t));
  void _msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$t প্রস্তুত করা হয়েছে।')));
}
